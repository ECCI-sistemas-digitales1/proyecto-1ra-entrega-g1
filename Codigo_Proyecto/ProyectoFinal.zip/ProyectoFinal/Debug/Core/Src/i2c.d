Core/Src/i2c.o: ../Core/Src/i2c.c \
 ../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f103xb.h \
 ../Drivers/CMSIS/Include/core_cm3.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Device/ST/STM32F1xx/Include/system_stm32f1xx.h \
 ../Core/Src/i2c.h ../Core/Src/i2c_lcd.h
../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f103xb.h:
../Drivers/CMSIS/Include/core_cm3.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Device/ST/STM32F1xx/Include/system_stm32f1xx.h:
../Core/Src/i2c.h:
../Core/Src/i2c_lcd.h:
